<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.2.0
    </div>
    <strong>Copyright &copy; 2024-2030 <a href="https://polinema.ac.id">Survey Polinema</a>.</strong> All rights reserved.
  </footer>